Android-USB-printer
===================

This app can connect and print messages to any USB printer via android.
