Android-Bluetooth-Printer
=========================

This app will print text to Bluetooth printer. I am using an android device and a Bluetooth printer. You can easily integrate this library to your project for printing support to Bluetooth printer.
